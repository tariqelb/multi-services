
import { pagePaddingSx } from "../../../Components/ui/PageContainer";
import PageHeader from "../../../Components/ui/PageHeader";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";

import {
    Box,
    Container,
    Paper,
    Tab,
    Tabs,
    Typography,
} from "@mui/material";

import PeopleAltIcon from "@mui/icons-material/PeopleAlt";
import AddCircleOutlineOutlinedIcon from "@mui/icons-material/AddCircleOutlineOutlined";

import RoommateList from "./RoommateList";
import RoommateInsertForm from "./RoommateInsertForm";

export default function RoommatePage() {
    const { t } = useTranslation();
    const [activeTab, setActiveTab] = useState(0);

    // Switch back to announcements after successful publication.
    const handleListingAdded = () => {
        setActiveTab(0);
    };

    return (
        <Box sx={pagePaddingSx}>
            {/* Page header */}
            <PageHeader
                icon={<PeopleAltIcon />}
                title={t("roommates.title", { defaultValue: "Find a Roommate" })}
                subtitle={t("roommates.subtitle", {
                    defaultValue: "Find a room, share your property, or connect with people looking to rent together.",
                })}
            />

            {/* Tabs */}
            <Paper
                elevation={0}
                sx={{
                    mb: 3,
                    border: "1px solid",
                    borderColor: "divider",
                    borderRadius: 2,
                    overflow: "hidden",
                }}
            >
                <Tabs
                    value={activeTab}
                    onChange={(_, newValue) => setActiveTab(newValue)}
                    variant="fullWidth"
                    textColor="primary"
                    indicatorColor="primary"
                    sx={{
                        "& .MuiTab-root": {
                            minHeight: 58,
                            textTransform: "none",
                            fontWeight: 600,
                            fontSize: {
                                xs: "0.8rem",
                                sm: "0.95rem",
                            },
                        },
                    }}
                >
                    <Tab
                        icon={<PeopleAltIcon />}
                        iconPosition="start"
                        label={t("roommates.announcements", {
                            defaultValue: "Announcements",
                        })}
                    />

                    <Tab
                        icon={<AddCircleOutlineOutlinedIcon />}
                        iconPosition="start"
                        label={t("roommates.addAnnouncement", {
                            defaultValue: "Add an announcement",
                        })}
                    />
                </Tabs>
            </Paper>

            {/* Announcements tab */}
            {activeTab === 0 && <RoommateList />}

            {/* Add announcement tab */}
            {activeTab === 1 && (
                <RoommateInsertForm
                    onAddListing={handleListingAdded}
                />
            )}
        </Box>
    );
}
