
import React from "react";
import { useTranslation } from "react-i18next";

import {
    Box,
    Card,
    CardActionArea,
    Chip,
    Stack,
    Typography,
    FormControl,
    Select,
    MenuItem,
} from "@mui/material";

import FeedbackOutlinedIcon from "@mui/icons-material/FeedbackOutlined";

const statusStyles = {
    open: { bgcolor: "#dbeafe", color: "#1d4ed8" },
    in_progress: { bgcolor: "#fef3c7", color: "#92400e" },
    resolved: { bgcolor: "#dcfce7", color: "#166534" },
    closed: { bgcolor: "#f1f5f9", color: "#475569" },
};

const priorityStyles = {
    low: { bgcolor: "#f1f5f9", color: "#475569" },
    medium: { bgcolor: "#fef3c7", color: "#92400e" },
    high: { bgcolor: "#fee2e2", color: "#b91c1c" },
};

const formatLabel = (value = "") =>
    String(value).replaceAll("_", " ").replace(/\b\w/g, (char) =>
        char.toUpperCase()
    );

const getLocale = (language) => {
    if (language?.startsWith("ar")) return "ar";
    if (language?.startsWith("fr")) return "fr-FR";
    return "en-GB";
};

export default function FeedbackList({
    feedbacks = [],
    selectedFeedback,
    onSelect,
    limit,
    onLimitChange,
    total = 0,
}) {
    const { t, i18n } = useTranslation();

    const translateValue = (value, category) => {
        if (!value) return "";

        return t(
            `adminFeedback.${category}.${value}`,
            formatLabel(value)
        );
    };

    const formatDate = (date) => {
        if (!date) {
            return t("adminFeedback.common.dateUnavailable");
        }

        return new Date(date).toLocaleDateString(
            getLocale(i18n.language),
            {
                day: "2-digit",
                month: "short",
                year: "numeric",
            }
        );
    };

    return (
        <Box
            sx={{
                border: "1px solid #e2e8f0",
                borderRadius: 3,
                bgcolor: "#fff",
                overflow: "hidden",
                minWidth: 0,
            }}
        >
            {/* List header */}
            <Box
                sx={{
                    px: 2,
                    py: 1.75,
                    borderBottom: "1px solid #e2e8f0",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: 1,
                    flexWrap: "wrap",
                }}
            >
                <Stack
                    direction="row"
                    spacing={1} sx={{ alignItems: "center" }}
                >
                    <Typography sx={{ fontWeight: 700, color: "#0f172a" }}>
                        {t("adminFeedback.list.submissions")}
                    </Typography>

                    <Chip
                        label={total}
                        size="small"
                        sx={{
                            fontWeight: 700,
                            bgcolor: "#eff6ff",
                            color: "#2563eb",
                        }}
                    />
                </Stack>

                <FormControl size="small">
                    <Select
                        value={limit}
                        onChange={(event) =>
                            onLimitChange(event.target.value)
                        }
                        sx={{
                            minWidth: 100,
                            fontSize: 13,
                            fontWeight: 600,
                            borderRadius: 2,
                        }}
                    >
                        <MenuItem value="10">10</MenuItem>
                        <MenuItem value="50">50</MenuItem>
                        <MenuItem value="all">
                            {t("adminFeedback.list.all")}
                        </MenuItem>
                    </Select>
                </FormControl>
            </Box>

            {/* Scrollable submissions */}
            <Box
                sx={{
                    height: {
                        xs: 420,
                        lg: 650,
                    },
                    overflowY: "auto",
                    overflowX: "hidden",
                    minHeight: 0,

                    scrollbarWidth: "thin",
                    scrollbarColor: "#94a3b8 #f1f5f9",

                    "&::-webkit-scrollbar": {
                        width: "7px",
                    },

                    "&::-webkit-scrollbar-track": {
                        bgcolor: "#f1f5f9",
                    },

                    "&::-webkit-scrollbar-thumb": {
                        bgcolor: "#94a3b8",
                        borderRadius: 10,
                    },

                    "&::-webkit-scrollbar-thumb:hover": {
                        bgcolor: "#64748b",
                    },
                }}
            >
                {feedbacks.map((feedback) => {
                    const isSelected =
                        selectedFeedback?._id === feedback._id;

                    return (
                        <Card
                            key={feedback._id}
                            elevation={0}
                            square
                            sx={{
                                borderBottom: "1px solid #f1f5f9",
                                bgcolor: isSelected ? "#eff6ff" : "#fff",
                                borderLeft: isSelected
                                    ? "3px solid #2563eb"
                                    : "3px solid transparent",
                            }}
                        >
                            <CardActionArea
                                onClick={() => onSelect(feedback)}
                                sx={{
                                    p: 2,
                                    "&:hover": {
                                        bgcolor: "#f8fafc",
                                    },
                                }}
                            >
                                <Stack spacing={1.2}>
                                    <Stack
                                        direction="row" sx={{ justifyContent: "space-between", alignItems: "flex-start", gap: 1 }}
                                    >
                                        <Stack
                                            direction="row"
                                            spacing={1}
                                            sx={{ alignItems: "center",
                                                minWidth: 0,
                                                flex: 1,
                                            }}
                                        >
                                            <FeedbackOutlinedIcon
                                                sx={{
                                                    color: "#2563eb",
                                                    fontSize: 19,
                                                    flexShrink: 0,
                                                }}
                                            />

                                            <Typography
                                                sx={{ fontWeight: 700, color: "#1e293b",
                                                    minWidth: 0,
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                    whiteSpace: "nowrap",
                                                }}
                                            >
                                                {feedback.subject}
                                            </Typography>
                                        </Stack>

                                        <Typography
                                            variant="caption"
                                            sx={{ color: "text.secondary",
                                                flexShrink: 0,
                                                whiteSpace: "nowrap",
                                            }}
                                        >
                                            {formatDate(feedback.createdAt)}
                                        </Typography>
                                    </Stack>

                                    <Typography
                                        variant="body2"
                                        sx={{ color: "text.secondary",
                                            display: "-webkit-box",
                                            WebkitLineClamp: 2,
                                            WebkitBoxOrient: "vertical",
                                            overflow: "hidden",
                                            overflowWrap: "anywhere",
                                        }}
                                    >
                                        {feedback.description}
                                    </Typography>

                                    <Stack
                                        direction="row"
                                        spacing={0.75}
                                        useFlexGap sx={{ flexWrap: "wrap" }}
                                    >
                                        <Chip
                                            label={translateValue(
                                                feedback.type,
                                                "types"
                                            )}
                                            size="small"
                                            variant="outlined"
                                        />

                                        <Chip
                                            label={translateValue(
                                                feedback.priority,
                                                "priorities"
                                            )}
                                            size="small"
                                            sx={{
                                                ...priorityStyles[feedback.priority],
                                                fontWeight: 600,
                                            }}
                                        />

                                        <Chip
                                            label={translateValue(
                                                feedback.status,
                                                "statuses"
                                            )}
                                            size="small"
                                            sx={{
                                                ...statusStyles[feedback.status],
                                                fontWeight: 600,
                                            }}
                                        />
                                    </Stack>

                                    <Typography
                                        variant="caption"
                                        noWrap sx={{ color: "text.secondary" }}
                                    >
                                        {feedback.email}
                                    </Typography>
                                </Stack>
                            </CardActionArea>
                        </Card>
                    );
                })}
            </Box>
        </Box>
    );
}
