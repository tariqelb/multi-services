import bcrypt from "bcryptjs";
import User from "../../DatabaseModels/Schema/User.js";
import jwt from "jsonwebtoken";
import { generateToken } from "../../utils/generateToken.js"

import { randomInt } from "crypto";
import PendingSignup from "../../DatabaseModels/Schema/PendingSignup.js";
import { sendVerificationEmail } from "../../services/emailService.js";
import { getUserWhatsApp, getWhatsAppPreferencesView } from "../../utils/whatsapp.js";

const authCookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
    path: "/",
};

export const signup = async (req, res) => {
    try {
        const {
            firstName,
            lastName,
            email,
            password,
            confirmPassword,
        } = req.body;

        if (
            !firstName?.trim() ||
            !lastName?.trim() ||
            !email?.trim() ||
            !password ||
            !confirmPassword
        ) {
            return res.status(400).json({
                message: "All fields are required.",
            });
        }

        if (firstName.trim().length < 2 ||
            lastName.trim().length < 2) {
            return res.status(400).json({
                message: "Names must contain at least 2 characters.",
            });
        }

        if (password.length < 8) {
            return res.status(400).json({
                message: "Password must contain at least 8 characters.",
            });
        }

        if (password !== confirmPassword) {
            return res.status(400).json({
                message: "Passwords do not match.",
            });
        }

        const normalizedEmail = email.trim().toLowerCase();

        const existingUser = await User.findOne({
            email: normalizedEmail,
        });

        if (existingUser) {
            return res.status(409).json({
                message: "An account with this email already exists.",
            });
        }

        // Generate verification code
        const code = randomInt(100000, 1000000).toString();

        // Hash password and verification code
        const hashedPassword = await bcrypt.hash(password, 12);
        const hashedCode = await bcrypt.hash(code, 10);

        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

        // Replace any previous pending registration
        await PendingSignup.findOneAndUpdate(
            { email: normalizedEmail },
            {
                $set: {
                    firstName: firstName.trim(),
                    lastName: lastName.trim(),
                    password: hashedPassword,
                    verificationCode: hashedCode,
                    attempts: 0,
                    expiresAt,
                },
            },
            { upsert: true, new: true, runValidators: true }
        );

        // Send verification email
        await sendVerificationEmail({
            to: normalizedEmail,
            code,
        });

        return res.status(200).json({
            message: "Verification code sent to your email.",
            email: normalizedEmail,
            expiresIn: 600,
        });
    } catch (error) {
        console.error("Signup error:", error.message);

        return res.status(500).json({
            message: "Unable to start registration. Please try again.",
        });
    }
};


export const verifyEmail = async (req, res) => {
    try {
        const { email, code } = req.body;

        if (!email?.trim() || !code?.trim()) {
            return res.status(400).json({
                message: "Email and verification code are required.",
            });
        }

        if (!/^\d{6}$/.test(code)) {
            return res.status(400).json({
                message: "Invalid verification code.",
            });
        }

        const normalizedEmail = email.trim().toLowerCase();

        const pendingSignup = await PendingSignup.findOne({
            email: normalizedEmail,
        }).select("+password +verificationCode");

        if (!pendingSignup) {
            return res.status(404).json({
                message: "Registration not found. Please signup again.",
            });
        }

        if (pendingSignup.expiresAt <= new Date()) {
            await PendingSignup.deleteOne({
                _id: pendingSignup._id,
            });

            return res.status(400).json({
                message: "Verification code expired. Please signup again.",
            });
        }

        if (pendingSignup.attempts >= 5) {
            await PendingSignup.deleteOne({
                _id: pendingSignup._id,
            });

            return res.status(429).json({
                message: "Too many attempts. Please signup again.",
            });
        }

        const isValidCode = await bcrypt.compare(
            code,
            pendingSignup.verificationCode
        );

        if (!isValidCode) {
            pendingSignup.attempts += 1;
            await pendingSignup.save();

            return res.status(400).json({
                message: "Incorrect verification code.",
                remainingAttempts: 5 - pendingSignup.attempts,
            });
        }

        // Check that the email was not registered meanwhile
        const existingUser = await User.findOne({
            email: normalizedEmail,
        });

        if (existingUser) {
            await PendingSignup.deleteOne({
                _id: pendingSignup._id,
            });

            return res.status(409).json({
                message: "An account with this email already exists.",
            });
        }

        // Create the actual user only after verification
        const user = await User.create({
            firstName: pendingSignup.firstName,
            lastName: pendingSignup.lastName,
            email: pendingSignup.email,
            password: pendingSignup.password,
        });

        await PendingSignup.deleteOne({
            _id: pendingSignup._id,
        });

        return res.status(201).json({
            message: "Email verified. Your account was created successfully.",
            user: {
                id: user._id,
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
                createdAt: user.createdAt,
            },
        });
    } catch (error) {
        console.error("Email verification error:", error.message);

        if (error.code === 11000) {
            return res.status(409).json({
                message: "An account with this email already exists.",
            });
        }

        return res.status(500).json({
            message: "Email verification failed.",
        });
    }
};


export const resendVerificationCode = async (req, res) => {
    try {
        const { email } = req.body;

        if (!email?.trim()) {
            return res.status(400).json({
                message: "Email is required.",
            });
        }

        const normalizedEmail = email.trim().toLowerCase();

        const pendingSignup = await PendingSignup.findOne({
            email: normalizedEmail,
        });

        if (!pendingSignup) {
            return res.status(404).json({
                message: "No pending registration found.",
            });
        }

        if (pendingSignup.expiresAt <= new Date()) {
            await PendingSignup.deleteOne({
                _id: pendingSignup._id,
            });

            return res.status(400).json({
                message: "Registration expired. Please signup again.",
            });
        }

        const code = randomInt(100000, 1000000).toString();

        pendingSignup.verificationCode = await bcrypt.hash(code, 10);
        pendingSignup.attempts = 0;
        pendingSignup.expiresAt = new Date(
            Date.now() + 10 * 60 * 1000
        );

        await pendingSignup.save();

        await sendVerificationEmail({
            to: normalizedEmail,
            code,
        });

        return res.status(200).json({
            message: "A new verification code has been sent.",
            expiresIn: 600,
        });
    } catch (error) {
        console.error("Resend verification error:", error.message);

        return res.status(500).json({
            message: "Unable to resend verification code.",
        });
    }
};



export const login = async (req, res) => {
    try {
        const { email, password } = req.body || {};

        // 400 - Missing credentials
        if (!email?.trim() || !password) {
            return res.status(400).json({
                success: false,
                code: "MISSING_CREDENTIALS",
                message: "Email and password are required.",
            });
        }

        // Find user.
        const user = await User.findOne({
            email: email.trim().toLowerCase(),
        }).select("+password");

        // 401 - Invalid credentials
        if (!user) {
            return res.status(401).json({
                success: false,
                code: "INVALID_CREDENTIALS",
                message: "Invalid email or password.",
            });
        }

        // Compare password.
        const isPasswordValid = await bcrypt.compare(
            password,
            user.password
        );

        if (!isPasswordValid) {
            return res.status(401).json({
                success: false,
                code: "INVALID_CREDENTIALS",
                message: "Invalid email or password.",
            });
        }

        // Suspended by an administrator: no login.
        if (user.accountStatus === "suspended") {
            return res.status(403).json({
                success: false,
                code: "ACCOUNT_SUSPENDED",
                message: "Your account has been suspended. Contact us if you think this is a mistake.",
                reason: user.suspendedReason || "",
            });
        }

        // Check JWT configuration.
        if (!process.env.JWT_SECRET) {
            console.error("[LOGIN] JWT_SECRET is not configured.");

            return res.status(500).json({
                success: false,
                code: "SERVER_CONFIGURATION_ERROR",
                message: "Login is temporarily unavailable.",
            });
        }

        // Cancel scheduled account deletion after successful authentication.
        if (user.scheduledDeletionAt) {
            user.deletionRequestedAt = null;
            user.scheduledDeletionAt = null;

            await user.save();
        }

        // Generate authentication token.
        const token = generateToken(user);

        // Set HTTP-only authentication cookie.
        res.cookie("token", token, {
            ...authCookieOptions,
            maxAge: 48 * 60 * 60 * 1000,
        });

        return res.status(200).json({
            success: true,
            code: "LOGIN_SUCCESS",
            message: "Login successful.",
            user: {
                id: user._id,
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
                createdAt: user.createdAt,
            },
            token,
        });

    } catch (error) {
        console.error("[LOGIN] Authentication error:", error);

        // Database connection problems.
        if (
            error.name === "MongooseServerSelectionError" ||
            error.name === "MongoNetworkError" ||
            error.name === "MongoNetworkTimeoutError"
        ) {
            return res.status(503).json({
                success: false,
                code: "DATABASE_UNAVAILABLE",
                message: "The authentication service is temporarily unavailable. Please try again later.",
            });
        }

        // Unexpected server error.
        return res.status(500).json({
            success: false,
            code: "INTERNAL_SERVER_ERROR",
            message: "An unexpected server error occurred during login.",
        });
    }
};


export const getMe = async (req, res) => {
    try {
        const user = await User.findById(req.user.userId)
            .select(
                "firstName lastName email language phoneNumber emailVerified phoneVerified whatsappNumber whatsappVerified notificationPreferences role address bio profileImage createdAt passwordSet +googleId"
            );

        if (!user) {
            return res.status(404).json({
                authenticated: false,
                message: "User not found",
            });
        }

        return res.status(200).json({
            authenticated: true,
            user: {
                id: user._id,
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
                language: user.language || "en",
                phoneNumber: user.phoneNumber,
                emailVerified: user.emailVerified,
                phoneVerified: user.phoneVerified,

                // WhatsApp number (next to the phone) and notification switches.
                whatsappNumber: user.whatsappNumber || "",
                whatsappVerified: getUserWhatsApp(user).verified,
                notificationPreferences: {
                    whatsapp: getWhatsAppPreferencesView(user),
                },

                role: user.role,
                address: user.address,
                bio: user.bio,
                profileImage: user.profileImage,
                createdAt: user.createdAt,

                // Google accounts may have no password yet.
                hasPassword: user.passwordSet !== false,
                googleLinked: Boolean(user.googleId),
            },
        });
    } catch (error) {
        console.error("[Auth] Get current user error:", error);

        return res.status(500).json({
            authenticated: false,
            message: "Failed to retrieve user profile",
        });
    }
};


export const logout = (req, res) => {
    res.clearCookie("token", authCookieOptions);

    return res.status(200).json({
        message: "Logout successful",
    });
};