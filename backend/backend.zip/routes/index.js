
import express from "express";

import authRouter from "./auth/AuthRoutes.js";
import profileRouter from "./profile/profileRouter.js";
import propertyRoutes from "./property/propertyRouter.js";
import notificationRouter from "./../Notification/notificationRouter.js";
import emailTestRouter from "./email/emailTestRouter.js";
import verificationRouter from "./verification/verificationRouter.js";
import accountDeletionRoutes from "./profile/accountDeletionRoutes.js";
import feedbackRoutes from "./feedback/feedbackRoutes.js";
import dashboardRouter from "./dashboard/dashboardRouter.js";
import externalListingRouter from "./externalListings/externalListingRouter.js";
import externalListingClickRoutes from "./externalListings/externalListingClickRoutes.js";
import externalListingAnalyticsRoutes from "./externalListings/externalListingAnalyticsRoutes.js";
import knowledgeRouter from "./knowledge/knowledgeRouter.js";
import roommateRouter from "./roommate/roommateRouter.js";
import roommateAlertRoutes from "./roommate/roommateAlertRoutes.js";
import establishmentRoutes from "./establishment/establishmentRoutes.js";

const router = express.Router();

router.use("/auth", authRouter);
router.use("/profile", profileRouter);
router.use("/profile/me/verification", verificationRouter);
router.use("/profile/me/account-deletion", accountDeletionRoutes);

router.use("/property", propertyRoutes);
router.use("/roommates", roommateRouter);

router.use("/notifications", notificationRouter);
router.use("/test-email", emailTestRouter);
router.use("/feedback", feedbackRoutes);
router.use("/dashboard", dashboardRouter);

router.use("/roommate/alerts", roommateAlertRoutes);
router.use("/establishments", establishmentRoutes);

// External listing analytics — register before dynamic listing routes.
router.use(
    "/external-listings/analytics",
    externalListingAnalyticsRoutes
);

// External listing click tracking.
router.use(
    "/external-listings",
    externalListingClickRoutes
);

// General external listing routes.
router.use(
    "/external-listings",
    externalListingRouter
);

router.use("/knowledge", knowledgeRouter);

export default router;
